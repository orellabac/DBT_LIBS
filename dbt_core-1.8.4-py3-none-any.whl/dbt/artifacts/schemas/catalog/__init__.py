# alias to latest
from dbt.artifacts.schemas.catalog.v1.catalog import *  # noqa
