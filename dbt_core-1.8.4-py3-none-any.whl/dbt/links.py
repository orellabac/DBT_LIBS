ProfileConfigDocs = "https://docs.getdbt.com/docs/configure-your-profile"
SnowflakeQuotingDocs = "https://docs.getdbt.com/v0.10/docs/configuring-quoting"
IncrementalDocs = "https://docs.getdbt.com/docs/configuring-incremental-models"
BigQueryNewPartitionBy = "https://docs.getdbt.com/docs/upgrading-to-0-16-0"
